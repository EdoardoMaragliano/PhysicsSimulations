/* AGGIORNATA AL 9 APRILE 2021
USO UN SOLO GENERATORE CON SEME INIZIALIZZATO A TIME(0)*/

#include <iostream>
#include <ctime>
#include <iomanip>
#include <vector>
#include <fstream>

#include "TRandom3.h"
#include "TGraph.h"
#include "TApplication.h"
#include "TAxis.h"
#include "TCanvas.h"
#include "TStyle.h"
#include "TSystem.h"
#include <functional>
#include <unistd.h>
#include "TH2I.h"

#include "Reticolo.hpp"


using namespace std;

//PRINTERS

void Reticolo::Print(){
	for(int i=0;i<m_rows;i++){
		for(int j=0;j<m_cols;j++){
			cout << m_matr[i][j] << " ";
		}
		cout << endl;
	}
}

void Reticolo::Print(string nomefile){
	ofstream fout(nomefile);
	for(int i=0;i<m_rows;i++){
		for(int j=0;j<m_cols;j++){ 
			fout << i << "\t" << j << "\t" << m_matr[i][j] << endl;
		}
		fout << endl;
	}
	fout.close();
}


void Reticolo::PrintGr(TH2I &grP){

	grP.Reset();
			
	for(int i=0;i<m_rows;++i){
		for(int j=0;j<m_cols;++j){
			if(m_matr[i][j]==true){
				grP.SetBinContent(i+1,j+1,50);		//TH1I numera i bin da 1 invece che da 0
			}
		}
	}
	gPad->Modified(); gPad->Update(); gSystem->ProcessEvents(); 
}

void Reticolo::Init(){
  
    // Inserting elements into vector 
    for (int i = 0; i < m_rows; i++) { 
        vector<bool> v_appo;
  
        for (int j = 0; j < m_cols; j++) { 
            v_appo.push_back(false); 
        } 
        m_matr.push_back(v_appo); 
    } 

	cout << "Reticolo inizializzato a 0" << endl;
}

int Reticolo::ContaParticelle(){
	int conta=0;
	for(int i=0;i<m_rows;i++){
		for(int j=0;j<m_cols;j++){
			if(m_matr[i][j]==true)
				conta++;
		}
	}
	return conta;
}



int Reticolo::NBounds(int x, int y){
	int N=0; //do per scontato che x,y sia un sito pieno

	int nx=x+1,ny=y+1,px=x-1,py=y-1;
	//implemento condiz al contorno cicliche(si puo' fare meglio, ma funziona)
	if(x==m_rows-1)
		nx=0;
	if(x==0)
		px=m_rows-1;
	if(y==m_cols-1)
		ny=0;
	if(y==0)
		py=m_cols-1;
	//conto i legami della particella nello stato  xy
	if(m_matr[px][y]==true)
		N++;
	if(m_matr[x][py]==true)
		N++;
	if(m_matr[nx][y]==true)
		N++;
	if(m_matr[x][ny]==true)
		N++;
	return N;
}

void Reticolo::CreaClassi(){
	for(int cl=0;cl<4;++cl)								//ogni volta che la chiamo 
		m_classi[cl].clear();							//ripulisco le classi

	for(int i=0;i<m_rows;i++){							//ciclo sul reticolo
		for(int j=0;j<m_cols;j++){
			if(m_matr[i][j]==true){						//se il sito è pieno
				vector<int> appo={i,j};					//salvo le coordinate del sito
				for(int cl=0;cl<4;++cl){	
					if(NBounds(i,j)==cl){				//se ho cl legami		
						m_classi[cl].push_back(appo);	//metto il punto nella classe cl	
					}	
				}	
			}
			/*else{
				vector<int> appo2={i,j};					//salvo le coordinate del sito
				m_classi[4].push_back(appo2);
			}*/
		}
	}
	/*cout << "processi divisi in classi" << endl;
	for(int i=0;i<5;++i)
		cout << "dim classe " << i << "=" << m_classi[i].size() << endl;	*/
}

void Reticolo::Crescita(double nu, double T, double E0, double Eb, double pDep){

	vector<double> p;													//contiene i pesi delle classi
	for(int i=0;i<4;++i){												//loop sulle 4 classi di diff
		p.push_back(m_classi[i].size()*(4-i)*nu*exp(-(E0+i*Eb)/T));		
		//cout <<	"classe"<<i<<"=" <<m_classi[i].size() << endl;
	}			
	p.push_back(pDep);	
	//cout << "p size=" << p.size() << endl;						//peso della deposizione costante
	
	double pTot=0;													//peso totale P(C)
	for(int j=0; j<p.size();++j){
		//cout << "p[" <<j <<"]=" << p[j] << endl;
		pTot+=p[j];	
	}
	//cout << "pTot=" << pTot << endl;

		double p0,p1,p2,p3;
		p0=(p[0]); p1=(p0+p[1]);p2=(p1+p[2]);p3=(p2+p[3]);
		
		
	//scelgo la classe
	int c=0;
	double r=m_rand.Rndm()*pTot;
	//cout << "estratto="<<r<<endl;

	if(0<r<p0){c=0;}					//0 vicini
	else if(p0<r<p1){c=1;}				//1 vicino
	else if(p1<r<p2){c=2;}				//2 vicini	
	else if(p2<r<p3){c=3;}				//3 vicini	
	else if(r>p3){c=4;}				//deposizione

	//scelgo la mossa all'interno della classe
	if(c<4){
		int k=m_rand.Integer(m_classi[c].size());	//numero di processi nella classe c scelta
		//cout << "c="<<c << "classi[c].size()="<<m_classi[c].size() << endl;
		//cout << "processo k=" << k << endl;
		int x=m_classi[c][k][0];					//scelgo un elemento della classe
		int y=m_classi[c][k][1];					
		this->Diffusione(x,y);
	}
	else{
		//depongo
		this->Deposizione();
	}
}

void Reticolo::Diffusione(int x, int y){	

	//0 su 1 dx 2 giu 3 sx
	
	int nextx=x+1,nexty=y+1,prevx=x-1,prevy=y-1;
	//implemento condiz al contorno cicliche(si puo' fare meglio, ma funziona)
	if(x==m_rows-1)
		nextx=0;
	if(x==0)
		prevx=m_rows-1;
	if(y==m_cols-1)
		nexty=0;
	if(y==0)
		prevy=m_cols-1;
	
	if(m_matr[x][y]==true){						//se il sito e' pieno

		int dir=m_rand.Integer(4); 				//estraggo una direzione 
		if(dir==0){								//mi sposto in su
			if (m_matr[prevx][y]==false){ 		//se è vuoto
				m_matr[x][y]=false;
				m_matr[prevx][y]=true;
			}		
		}
		if(dir==1){								//mi sposto a dx
			if (m_matr[x][nexty]==false){			
				m_matr[x][y]=false;
				m_matr[x][nexty]=true;
			}			
		}
		if(dir==2){								//mi sposto in giu
			if (m_matr[nextx][y]==false){ 
				m_matr[x][y]=false;
				m_matr[nextx][y]=true;
			}		
		}
		if(dir==3){								//mi sposto a sx
			if (m_matr[x][prevy]==false){	
				m_matr[x][y]=false;
				m_matr[x][prevy]=true;	
			}		
		}
	}
	//cout << "diffusione effettuata" << endl;
}

void Reticolo::Deposizione(){
	int x=m_rand.Integer(m_rows); 							//estraggo un sito a caso	
	int y=m_rand.Integer(m_cols);
	while(m_matr[x][y]==true){								//finchè il sito estratto è pieno
		x=m_rand.Integer(m_rows); 							//continuo ad estrarre		
		y=m_rand.Integer(m_cols);							
	}
	m_matr[x][y]=true;					//quando esce dal ciclo(cioe' il sito è vuoto), lo riempio
	m_Npart++;							//se deposito, aggiorno il numero di particelle
	cout << "deposizione effettuata, nPart=" <<m_Npart<< endl;

}

void Reticolo::RandomFill(int Nfilled){
	int conta=0;
	int x=0, y=0;
	
	while(conta<Nfilled){
		x=m_rand.Integer(m_rows);		//estaggo indice tra 0 e L-1
		y=m_rand.Integer(m_cols);	

		if(m_matr[x][y]==false){  		//se la coordinata è vuota
			m_matr[x][y]=true;	   		//riempila	
			conta++;				  	//e aggiorna il conto
			m_Npart++;					//aggiorna il contatore interno alla classe
		}	
	}
	cout << "Reticolo riempito correttamente, nPart="<< m_Npart << endl;
}

void Reticolo::ComputeParOrdine(){
	float N_A=0, N_B=0;
	//fisso la riga
	for(int i=0;i<m_rows;i++){
		for(int j=0;j<m_cols;j++){
			if(m_matr[i][j]==true){
				if((i+j)%2==0)		//entrambi pari o entrambi dispari
					N_A++;
				if((i+j)%2==1)		//un pari e un dispari
					N_B++;
			}
		}
		m_p=(N_A-N_B)/(N_A+N_B);
	}	
}



//GETTERS

vector<vector<bool>> Reticolo::GetMatrix(){
	return m_matr;
}

int Reticolo::GetNPart(){
	return m_Npart;
}

double Reticolo::GetParOrdine(){
	return m_p;
}

vector<vector<int>>* Reticolo::GetClassi(){
	return m_classi;
}