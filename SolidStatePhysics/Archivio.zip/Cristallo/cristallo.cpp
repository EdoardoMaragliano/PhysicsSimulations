#include <iostream>
#include <ctime>
#include <iomanip>
#include <vector>
#include <fstream>

#include "TRandom3.h"
#include "TGraph.h"
#include "TApplication.h"
#include "TAxis.h"
#include "TCanvas.h"
#include "TStyle.h"
#include "TSystem.h"
#include <functional>
#include <unistd.h>
#include "TH2I.h"
#include <unistd.h>

#include "Reticolo.hpp"

using namespace std;

	int L=64;
	int M=L*L;							//numero siti totali
	//double kb=1.380649E-23;

	double theta=0.1; 					//riempimento percentuale massimo
		
	double T=200;						//interazione attrattiva
	double nu=1E12;
	double E0=0.4*11604; //eV->K 		//E0 barriera per un atomo senza primi vicini
	double Eb=0.2*11604; //eV->K 		//eBound di legame
	double F=1./60;						//flusso di deposizione

	double pDep=double(M)*F;	//peso della deposizione costante
	TRandom3 rnd;

//ALCUNE FUNZIONI
int approx(float a){				//non trovavo una funzione che approssimasse alla parte
	float appo= a-int(a);			//intera piu' vicina cosi' l'ho scritta
	if(appo<0.5)
		return floor(a);
	else
		return ceil(a);
}



//MAIN
int main(int argc, char **argv){

	int N_max = approx(M*theta); 				//numero massimo siti pieni
	cout << "n max= " << N_max << endl;

	TH2I grEvol("Evoluzione: step 0","",L,0,L,L,0,L);
	TApplication app("app",NULL, NULL);
	
    gStyle->SetOptStat(0);

	Reticolo matrice(L,L,2);						//creo reticolo con 8 particelle
	
	TCanvas can_dyn;
	can_dyn.SetTitle("Evoluzione");
	
	cout << "carico evoluzione dinamica del sistema" << endl;
	matrice.PrintGr(grEvol);
	grEvol.SetTitle("Evoluzione temporale:step 0");
	
	grEvol.Draw("COL");
	
	matrice.PrintGr(grEvol);


	int conta=0;
	while(matrice.GetNPart()<N_max){				//finchè non raggiungo il riempimento massimo
	//for(int j=0;j<10000000;++j){
		//deposizione oppure diffusione -> estraggo una classe 0 1 2 3 4
		//se diffusione estraggo unif in 1-n_mosse(C) e scelgo la mossa corrispondente
		//se deposizione matrice.Deposition()
		matrice.CreaClassi();
		matrice.Crescita(nu,T, E0, Eb, pDep);
		
		if(conta%100==0){
			//usleep(100000);
			matrice.PrintGr(grEvol);
			string title="Evoluzione Temporale: step "+to_string(conta);
			grEvol.SetTitle(title.c_str());
		}

		//cout << matrice.GetNPart()<< "\t" << matrice.ContaParticelle()<<endl;
		++conta;
	}
	cout << "n iterazioni="<<conta<<endl;
	matrice.PrintGr(grEvol);
	cout << matrice.GetNPart()<< "\t" << matrice.ContaParticelle()<<endl;
	cout <<"app.Run(true)"<< endl;
	app.Run(true);


	return 0;
}